#' Create a new data project from the standard template
#'
#' Called automatically by RStudio/Positron's "New Project" wizard when the
#' "Data Project Template" option is selected. Builds the standard folder
#' structure with placeholder files so empty directories are kept in git.
#'
#' @param path Path to the new project directory (provided by the IDE).
#' @param ... Additional arguments passed by the IDE (unused).
#' @export
data_project_template <- function(path, ...) {
  dir.create(path, recursive = TRUE, showWarnings = FALSE)

  dirs <- c(
    "data/raw", "data/interim", "data/processed",
    "notebooks",
    "src",
    "outputs/figures", "outputs/tables",
    "docs",
    "tests"
  )
  for (d in dirs) {
    dir.create(file.path(path, d), recursive = TRUE, showWarnings = FALSE)
    # keep empty dirs tracked in git
    file.create(file.path(path, d, ".gitkeep"))
  }

  writeLines(
    c(
      "# Project Title",
      "",
      "## Overview",
      "Brief description of what this project does.",
      "",
      "## Folder Structure",
      "- `data/raw` — original, unmodified data",
      "- `data/interim` — cleaned/intermediate data",
      "- `data/processed` — final, analysis-ready data",
      "- `notebooks` — exploratory notebooks / Rmd / qmd",
      "- `src` — reusable functions and scripts",
      "- `outputs/figures` — generated plots",
      "- `outputs/tables` — generated tables",
      "- `docs` — project documentation",
      "- `tests` — unit tests"
    ),
    file.path(path, "README.md")
  )

  writeLines(
    c(
      ".Rproj.user/",
      ".Rhistory",
      ".RData",
      ".Ruserdata",
      "data/raw/*",
      "!data/raw/.gitkeep",
      "data/interim/*",
      "!data/interim/.gitkeep",
      "outputs/figures/*",
      "!outputs/figures/.gitkeep"
    ),
    file.path(path, ".gitignore")
  )

  writeLines("# Data Dictionary\n", file.path(path, "docs", "data_dictionary.md"))
  writeLines("# Decisions Log\n", file.path(path, "docs", "decisions.md"))
  writeLines("# Project Notes\n", file.path(path, "docs", "project_notes.md"))

  invisible(TRUE)
}
