#' Create a new project from the template and open it in Positron
#'
#' @param name Name of the new project folder (e.g. "report-automation")
#' @param parent_dir Folder where new projects live. Defaults to
#'   "C:/Users/MorganaKinlan/Projects" - change this once to fit your setup.
new_project <- function(name, parent_dir = "C:/Users/MorganaKinlan/Projects") {
  path <- file.path(parent_dir, name)
  myTemplates::data_project_template(path)
  cat("Created:", path, "\n")

  # Try to open it in Positron automatically (requires 'positron' on PATH)
  opened <- tryCatch({
    system2("positron", args = shQuote(path))
    TRUE
  }, error = function(e) FALSE)

  if (!opened) {
    cat("Open it manually: File > Open Folder >", path, "\n")
  }
}
